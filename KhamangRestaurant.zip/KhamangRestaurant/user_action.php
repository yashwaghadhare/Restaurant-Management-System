<?php
include_once 'config/Database.php';
include_once 'class/User.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

if(!empty($_POST['action']) && $_POST['action'] == 'listUsers') {
	$user->listUsers();
}

if(!empty($_POST['action']) && $_POST['action'] == 'getUsersDetails') {
	$user->id = $_POST["id"];
	$user->getUserDetails();
}

if(!empty($_POST['action']) && $_POST['action'] == 'addUser') {
	$user->userName = $_POST["userName"];
	$user->percentage = $_POST["percentage"];
	$user->status = $_POST["status"];
	$user->insert();
}

if(!empty($_POST['action']) && $_POST['action'] == 'updateuser') {
	$user->id = $_POST["id"];
	$user->userName = $_POST["userName"];
	$user->percentage = $_POST["percentage"];
	$user->status = $_POST["status"];	
	$user->update();
}

if(!empty($_POST['action']) && $_POST['action'] == 'delete') {
	$user->id = $_POST["id"];
	$user->delete();
}
?>